import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Search, Filter, X } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export interface SearchFilters {
  specialty: string;
  quantity: number;
  startDate: Date | undefined;
  contractDuration: string;
  experience: string;
  languages: string[];
  location: string;
  availability: string;
}

interface SearchFiltersProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  onSearch: () => void;
  onReset: () => void;
}

const SearchFiltersComponent = ({ filters, onFiltersChange, onSearch, onReset }: SearchFiltersProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const updateFilter = (key: keyof SearchFilters, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const specialties = [
    "Especialistas Geriátricos",
    "Especialistas en Urgencias", 
    "Especialistas en Atención Infantil",
    "Enfermería General",
    "Cuidados Intensivos",
    "Cirugía",
    "Cardiología",
    "Oncología"
  ];

  const contractDurations = [
    "1 mes",
    "3 meses", 
    "6 meses",
    "1 año",
    "2 años",
    "Permanente"
  ];

  const experienceLevels = [
    "1-2 años",
    "3-5 años",
    "6-10 años",
    "10+ años"
  ];

  const availableLanguages = [
    "Noruego",
    "Finlandés", 
    "Sueco",
    "Danés",
    "Inglés",
    "Español"
  ];

  return (
    <Card className="w-full bg-card border-border shadow-md">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5 text-primary" />
            Buscar Personal Médico
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            <Filter className="h-4 w-4 mr-2" />
            {isExpanded ? "Menos filtros" : "Más filtros"}
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Main search bar */}
        <div className="flex gap-4">
          <div className="flex-1">
            <Input
              placeholder="Ej: Quiero 3 especialistas para el 1 de junio con duración de 3 meses"
              className="search-input"
              value={`${filters.quantity > 0 ? filters.quantity + ' ' : ''}${filters.specialty}${filters.startDate ? ' para el ' + format(filters.startDate, 'dd/MM/yyyy') : ''}${filters.contractDuration ? ' con duración de ' + filters.contractDuration : ''}`}
              readOnly
            />
          </div>
          <Button onClick={onSearch} className="bg-primary hover:bg-primary-dark">
            <Search className="h-4 w-4" />
          </Button>
        </div>

        {/* Basic filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Especialidad</Label>
            <Select value={filters.specialty} onValueChange={(value) => updateFilter('specialty', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar especialidad" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map((specialty) => (
                  <SelectItem key={specialty} value={specialty}>
                    {specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Cantidad</Label>
            <Input
              type="number"
              min="1"
              placeholder="Ej: 3"
              value={filters.quantity || ''}
              onChange={(e) => updateFilter('quantity', parseInt(e.target.value) || 0)}
            />
          </div>

          <div className="space-y-2">
            <Label>Fecha de inicio</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.startDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.startDate ? format(filters.startDate, "dd/MM/yyyy") : "Seleccionar fecha"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={filters.startDate}
                  onSelect={(date) => updateFilter('startDate', date)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {/* Expanded filters */}
        {isExpanded && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t">
            <div className="space-y-2">
              <Label>Duración del contrato</Label>
              <Select value={filters.contractDuration} onValueChange={(value) => updateFilter('contractDuration', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Duración" />
                </SelectTrigger>
                <SelectContent>
                  {contractDurations.map((duration) => (
                    <SelectItem key={duration} value={duration}>
                      {duration}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Experiencia</Label>
              <Select value={filters.experience} onValueChange={(value) => updateFilter('experience', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Años de experiencia" />
                </SelectTrigger>
                <SelectContent>
                  {experienceLevels.map((level) => (
                    <SelectItem key={level} value={level}>
                      {level}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Ubicación</Label>
              <Input
                placeholder="Ciudad o región"
                value={filters.location}
                onChange={(e) => updateFilter('location', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Disponibilidad</Label>
              <Select value={filters.availability} onValueChange={(value) => updateFilter('availability', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Disponible</SelectItem>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="all">Todos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}

        {/* Action buttons */}
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={onReset}>
            <X className="h-4 w-4 mr-2" />
            Limpiar filtros
          </Button>
          <Button onClick={onSearch} className="bg-primary hover:bg-primary-dark">
            Buscar Personal
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default SearchFiltersComponent;