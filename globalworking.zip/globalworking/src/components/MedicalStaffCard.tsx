import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MapPin, Calendar, Clock, Star, Languages as LanguagesIcon } from "lucide-react";

interface MedicalStaffCardProps {
  id: string;
  name: string;
  specialty: string;
  experience: number;
  availability: "available" | "pending" | "busy";
  rating: number;
  location: string;
  languages: string[];
  availableFrom: string;
  contractType: string;
  photo: string;
  certifications: string[];
  onViewDetails: (id: string) => void;
}

const MedicalStaffCard = ({
  id,
  name,
  specialty,
  experience,
  availability,
  rating,
  location,
  languages,
  availableFrom,
  contractType,
  photo,
  certifications,
  onViewDetails,
}: MedicalStaffCardProps) => {
  const [cardLanguage, setCardLanguage] = useState<'en' | 'no'>('en');

  const translations = {
    en: {
      yearsExp: "years exp.",
      availableFrom: "Available from",
      languages: "Languages:",
      certifications: "Certifications:",
      viewDetails: "View Details",
      status: {
        available: "Available",
        pending: "Pending",
        busy: "Busy"
      }
    },
    no: {
      yearsExp: "års erf.",
      availableFrom: "Tilgjengelig fra",
      languages: "Språk:",
      certifications: "Sertifiseringer:",
      viewDetails: "Se Detaljer",
      status: {
        available: "Tilgjengelig",
        pending: "Venter",
        busy: "Opptatt"
      }
    }
  };

  const t = translations[cardLanguage];

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "available":
        return "status-available";
      case "pending":
        return "status-pending";
      default:
        return "status-busy";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "available":
        return t.status.available;
      case "pending":
        return t.status.pending;
      default:
        return t.status.busy;
    }
  };

  return (
    <Card className="card-hover w-full max-w-sm bg-card border-border">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-3">
            <Avatar className="h-12 w-12">
              <AvatarImage src={photo} alt={name} />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-foreground">{name}</h3>
              <p className="text-sm text-muted-foreground">{specialty}</p>
            </div>
          </div>
          <Badge className={`${getStatusStyle(availability)} text-xs`}>
            {getStatusText(availability)}
          </Badge>
        </div>
        <div className="flex justify-end">
          <Button
            size="sm"
            variant="ghost"
            className="h-7 text-xs"
            onClick={(e) => {
              e.stopPropagation();
              setCardLanguage(cardLanguage === 'en' ? 'no' : 'en');
            }}
          >
            <LanguagesIcon className="mr-1 h-3 w-3" />
            {cardLanguage === 'en' ? 'NO' : 'EN'}
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 text-yellow-500 fill-current" />
            <span className="font-medium">{rating}</span>
          </div>
          <span className="text-muted-foreground">{experience} {t.yearsExp}</span>
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{location}</span>
          </div>
          
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>{t.availableFrom} {availableFrom}</span>
          </div>
          
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>{contractType}</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <LanguagesIcon className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">{t.languages}</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {languages.map((lang) => (
              <Badge key={lang} variant="secondary" className="text-xs">
                {lang}
              </Badge>
            ))}
          </div>
        </div>

        {certifications.length > 0 && (
          <div className="space-y-2">
            <span className="text-sm font-medium">{t.certifications}</span>
            <div className="flex flex-wrap gap-1">
              {certifications.slice(0, 2).map((cert) => (
                <Badge key={cert} variant="outline" className="text-xs">
                  {cert}
                </Badge>
              ))}
              {certifications.length > 2 && (
                <Badge variant="outline" className="text-xs">
                  +{certifications.length - 2}
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter>
        <Button 
          onClick={() => onViewDetails(id)}
          className="w-full bg-primary hover:bg-primary-dark text-primary-foreground"
        >
          {t.viewDetails}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default MedicalStaffCard;