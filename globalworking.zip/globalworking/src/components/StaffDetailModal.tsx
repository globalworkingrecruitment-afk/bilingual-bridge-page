import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { 
  MapPin, 
  Calendar, 
  Clock, 
  Star, 
  Languages, 
  GraduationCap,
  Award,
  Phone,
  Mail,
  FileText,
  DollarSign,
  CalendarPlus
} from "lucide-react";

interface StaffMember {
  id: string;
  name: string;
  specialty: string;
  experience: number;
  availability: "available" | "pending" | "busy";
  rating: number;
  location: string;
  languages: string[];
  availableFrom: string;
  contractType: string;
  photo: string;
  certifications: string[];
  education: string[];
  email: string;
  phone: string;
  description: string;
  hourlyRate: number;
  monthlyRate: number;
  skills: string[];
}

interface StaffDetailModalProps {
  staff: StaffMember | null;
  isOpen: boolean;
  onClose: () => void;
  onScheduleInterview: (staffId: string) => void;
  onViewContract: (staffId: string) => void;
  onViewCosts: (staffId: string) => void;
}

const StaffDetailModal = ({ 
  staff, 
  isOpen, 
  onClose, 
  onScheduleInterview,
  onViewContract,
  onViewCosts 
}: StaffDetailModalProps) => {
  if (!staff) return null;

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "available":
        return "status-available";
      case "pending":
        return "status-pending";
      default:
        return "status-busy";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "available":
        return "Disponible";
      case "pending":
        return "Pendiente";
      default:
        return "Ocupado";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <Avatar className="h-16 w-16">
              <AvatarImage src={staff.photo} alt={staff.name} />
              <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                {staff.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-2xl font-bold text-foreground">{staff.name}</h2>
              <p className="text-muted-foreground">{staff.specialty}</p>
              <Badge className={`${getStatusStyle(staff.availability)} mt-2`}>
                {getStatusText(staff.availability)}
              </Badge>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Main Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Información Básica
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">{staff.description}</p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-yellow-500 fill-current" />
                    <span className="font-medium">{staff.rating}/5.0</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{staff.experience} años de experiencia</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{staff.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Disponible desde {staff.availableFrom}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Education & Certifications */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GraduationCap className="h-5 w-5 text-primary" />
                  Educación y Certificaciones
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Educación:</h4>
                  <div className="space-y-2">
                    {staff.education.map((edu, index) => (
                      <div key={index} className="text-sm text-muted-foreground">
                        • {edu}
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-2">Certificaciones:</h4>
                  <div className="flex flex-wrap gap-2">
                    {staff.certifications.map((cert) => (
                      <Badge key={cert} variant="outline" className="flex items-center gap-1">
                        <Award className="h-3 w-3" />
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Skills & Languages */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Languages className="h-5 w-5 text-primary" />
                  Idiomas y Habilidades
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Idiomas:</h4>
                  <div className="flex flex-wrap gap-2">
                    {staff.languages.map((lang) => (
                      <Badge key={lang} variant="secondary">
                        {lang}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-2">Habilidades Especializadas:</h4>
                  <div className="flex flex-wrap gap-2">
                    {staff.skills.map((skill) => (
                      <Badge key={skill} variant="outline">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Contact & Actions */}
          <div className="space-y-6">
            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5 text-primary" />
                  Contacto
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{staff.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{staff.phone}</span>
                </div>
              </CardContent>
            </Card>

            {/* Pricing */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  Tarifas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm">
                  <span className="font-medium">Por hora: </span>
                  <span className="text-lg font-bold text-primary">€{staff.hourlyRate}</span>
                </div>
                <div className="text-sm">
                  <span className="font-medium">Por mes: </span>
                  <span className="text-lg font-bold text-primary">€{staff.monthlyRate.toLocaleString()}</span>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button 
                onClick={() => onScheduleInterview(staff.id)}
                className="w-full bg-success hover:bg-success/90 text-success-foreground"
                disabled={staff.availability === "busy"}
              >
                <CalendarPlus className="h-4 w-4 mr-2" />
                Agendar Entrevista
              </Button>

              <Button 
                onClick={() => onViewContract(staff.id)}
                variant="outline"
                className="w-full"
              >
                <FileText className="h-4 w-4 mr-2" />
                Simular Contrato
              </Button>

              <Button 
                onClick={() => onViewCosts(staff.id)}
                variant="outline"
                className="w-full"
              >
                <DollarSign className="h-4 w-4 mr-2" />
                Ver Costos Detallados
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default StaffDetailModal;