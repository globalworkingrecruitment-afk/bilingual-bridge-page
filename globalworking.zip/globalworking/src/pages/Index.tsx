import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import MedicalStaffCard from "@/components/MedicalStaffCard";
import SearchFiltersComponent, { SearchFilters } from "@/components/SearchFilters";
import StaffDetailModal from "@/components/StaffDetailModal";
import { mockStaff, searchStaff, StaffMember } from "@/data/mockStaff";
import { supabase } from "@/integrations/supabase/client";
import heroImage from "@/assets/medical-hero.jpg";
import { 
  Users, 
  Globe, 
  Award, 
  TrendingUp,
  Heart,
  UserCheck,
  Clock,
  Star,
  Languages
} from "lucide-react";

const Index = () => {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<'en' | 'no'>('en');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/auth");
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }
  const [filters, setFilters] = useState<SearchFilters>({
    specialty: "",
    quantity: 0,
    startDate: undefined,
    contractDuration: "",
    experience: "",
    languages: [],
    location: "",
    availability: ""
  });
  
  const [searchResults, setSearchResults] = useState<StaffMember[]>(mockStaff);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { toast } = useToast();

  const translations = {
    en: {
      hero: {
        badge: "globalWorking - Talent Management Platform",
        title: "Client Portal",
        subtitle: "Access your personalized catalog of certified medical professionals for Norway and Finland. Manage interviews, contracts and selection processes from one platform.",
        features: "✓ Pre-selected staff ✓ Updated availability ✓ Comprehensive management",
        exploreCandidates: "Explore Candidates",
        controlPanel: "Control Panel",
        response: "Response in 24 hours • Hassle-free process • Satisfaction guarantee"
      },
      stats: {
        title: "Your Professional Network",
        subtitle: "Your candidate portfolio statistics",
        certifiedProfessionals: "Certified Professionals",
        hospitalsServed: "Norwegian Hospitals Served",
        avgPlacement: "Average Placement Time",
        satisfaction: "Hospital Satisfaction",
        premiumTitle: "🚀 globalWorking - Premium Service",
        premiumDesc: "Personalized portal • Pre-filtered candidates • Complete management • 24/7 support"
      },
      filters: {
        title: "Advanced Filters",
        subtitle: "Use smart filters to find candidates that match exactly your selection criteria and availability dates."
      },
      specialties: {
        title: "Available",
        titleHighlight: "Specialties",
        subtitle: "Select a specialty to see only those professionals",
        geriatric: "Geriatric Specialists",
        emergency: "Emergency Specialists",
        pediatric: "Pediatric Care Specialists",
        general: "General Nursing",
        intensive: "Intensive Care",
        available: "available",
        ready: "Ready",
        selected: "✓ Specialty selected",
        clickToView: "Click to see only"
      },
      staff: {
        title: "Available Staff",
        showingResults: "Showing results for:",
        noResults: "No professionals found",
        noResultsDesc: "Try adjusting search filters to get more results",
        clearFilters: "Clear filters"
      },
      cta: {
        title: "Need more candidates for your project?",
        subtitle: "Request an expansion of your candidate portfolio or adjust selection criteria to access more qualified professionals.",
        explore: "🔍 Explore",
        exploreDesc: "Review candidates",
        select: "📋 Select",
        selectDesc: "Mark favorites",
        contact: "📞 Contact",
        contactDesc: "Schedule interviews",
        accountManager: "📞 Account Manager",
        reports: "📊 Detailed Reports"
      },
      toast: {
        filtered: "Filtered by",
        showing: "Showing",
        professionals: "professionals of this specialty",
        searchCompleted: "Search completed",
        foundProfessionals: "professionals found matching the criteria",
        interviewScheduled: "Interview scheduled",
        interviewDesc: "An interview request has been sent to the candidate",
        contractSimulation: "Contract simulation",
        contractDesc: "A personalized contract simulation has been generated",
        costAnalysis: "Cost analysis",
        costDesc: "A detailed staff cost analysis has been generated",
        controlPanelTitle: "Control Panel",
        controlPanelDesc: "Accessing your personalized dashboard..."
      }
    },
    no: {
      hero: {
        badge: "globalWorking - Talentstyringplattform",
        title: "Klientportal",
        subtitle: "Få tilgang til din personlige katalog over sertifiserte medisinske fagfolk for Norge og Finland. Administrer intervjuer, kontrakter og utvelgelsesprosesser fra én plattform.",
        features: "✓ Forhåndsvalgt personale ✓ Oppdatert tilgjengelighet ✓ Omfattende administrasjon",
        exploreCandidates: "Utforsk Kandidater",
        controlPanel: "Kontrollpanel",
        response: "Respons innen 24 timer • Problemfri prosess • Tilfredsgaranti"
      },
      stats: {
        title: "Ditt Profesjonelle Nettverk",
        subtitle: "Statistikk for kandidatporteføljen din",
        certifiedProfessionals: "Sertifiserte Fagfolk",
        hospitalsServed: "Norske Sykehus Betjent",
        avgPlacement: "Gjennomsnittlig Plasseringstid",
        satisfaction: "Sykehustilfredshet",
        premiumTitle: "🚀 globalWorking - Premium Service",
        premiumDesc: "Personlig portal • Forhåndsfiltrerte kandidater • Fullstendig administrasjon • 24/7 support"
      },
      filters: {
        title: "Avanserte Filtre",
        subtitle: "Bruk smarte filtre for å finne kandidater som matcher nøyaktig dine utvelgelseskriterier og tilgjengelighetsdatoer."
      },
      specialties: {
        title: "Tilgjengelige",
        titleHighlight: "Spesialiteter",
        subtitle: "Velg en spesialitet for å se bare disse fagfolkene",
        geriatric: "Geriatriske Spesialister",
        emergency: "Akuttspesialister",
        pediatric: "Barneomsorgsspesialister",
        general: "Generell Sykepleie",
        intensive: "Intensivbehandling",
        available: "tilgjengelige",
        ready: "Klare",
        selected: "✓ Spesialitet valgt",
        clickToView: "Klikk for å se bare"
      },
      staff: {
        title: "Tilgjengelig Personale",
        showingResults: "Viser resultater for:",
        noResults: "Ingen fagfolk funnet",
        noResultsDesc: "Prøv å justere søkefiltrene for å få flere resultater",
        clearFilters: "Tøm filtre"
      },
      cta: {
        title: "Trenger du flere kandidater til prosjektet ditt?",
        subtitle: "Be om en utvidelse av kandidatporteføljen din eller juster utvelgelseskriteriene for å få tilgang til flere kvalifiserte fagfolk.",
        explore: "🔍 Utforsk",
        exploreDesc: "Gjennomgå kandidater",
        select: "📋 Velg",
        selectDesc: "Merk favoritter",
        contact: "📞 Kontakt",
        contactDesc: "Planlegg intervjuer",
        accountManager: "📞 Kontoansvarlig",
        reports: "📊 Detaljerte Rapporter"
      },
      toast: {
        filtered: "Filtrert etter",
        showing: "Viser",
        professionals: "fagfolk av denne spesialiteten",
        searchCompleted: "Søk fullført",
        foundProfessionals: "fagfolk funnet som matcher kriteriene",
        interviewScheduled: "Intervju planlagt",
        interviewDesc: "En intervjuforespørsel er sendt til kandidaten",
        contractSimulation: "Kontraktsimulering",
        contractDesc: "En personlig kontraktsimulering er generert",
        costAnalysis: "Kostnadsanalyse",
        costDesc: "En detaljert kostnadsanalyse for personalet er generert",
        controlPanelTitle: "Kontrollpanel",
        controlPanelDesc: "Får tilgang til ditt personlige dashbord..."
      }
    }
  };

  const t = translations[language];

  const handleSpecialtyClick = (specialtyName: string) => {
    const updatedFilters = { ...filters, specialty: specialtyName };
    setFilters(updatedFilters);
    const results = searchStaff(updatedFilters);
    setSearchResults(results);
    toast({
      title: `${t.toast.filtered} ${specialtyName}`,
      description: `${t.toast.showing} ${results.length} ${t.toast.professionals}`,
    });
  };

  const handleSearch = () => {
    const results = searchStaff(filters);
    setSearchResults(results);
    toast({
      title: t.toast.searchCompleted,
      description: `${results.length} ${t.toast.foundProfessionals}`,
    });
  };

  const handleReset = () => {
    setFilters({
      specialty: "",
      quantity: 0,
      startDate: undefined,
      contractDuration: "",
      experience: "",
      languages: [],
      location: "",
      availability: ""
    });
    setSearchResults(mockStaff);
  };

  const handleViewDetails = (staffId: string) => {
    const staff = mockStaff.find(s => s.id === staffId);
    if (staff) {
      setSelectedStaff(staff);
      setIsModalOpen(true);
    }
  };

  const handleScheduleInterview = (staffId: string) => {
    toast({
      title: t.toast.interviewScheduled,
      description: t.toast.interviewDesc,
    });
    setIsModalOpen(false);
  };

  const handleViewContract = (staffId: string) => {
    toast({
      title: t.toast.contractSimulation,
      description: t.toast.contractDesc,
    });
  };

  const handleViewCosts = (staffId: string) => {
    toast({
      title: t.toast.costAnalysis,
      description: t.toast.costDesc,
    });
  };

  const scrollToCandidates = () => {
    const candidatesSection = document.getElementById('candidates-section');
    if (candidatesSection) {
      candidatesSection.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }
  };

  const handleControlPanel = () => {
    toast({
      title: t.toast.controlPanelTitle,
      description: t.toast.controlPanelDesc,
    });
  };

  const specialties = [
    { name: t.specialties.geriatric, count: 2, icon: Heart },
    { name: t.specialties.emergency, count: 2, icon: TrendingUp },
    { name: t.specialties.pediatric, count: 2, icon: Users },
    { name: t.specialties.general, count: 1, icon: UserCheck },
    { name: t.specialties.intensive, count: 1, icon: Award },
  ];

  const stats = [
    { label: t.stats.certifiedProfessionals, value: "500+", icon: Users },
    { label: t.stats.hospitalsServed, value: "45+", icon: Globe },
    { label: t.stats.avgPlacement, value: "21 " + (language === 'en' ? 'days' : 'dager'), icon: Clock },
    { label: t.stats.satisfaction, value: "4.9/5", icon: Star },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-24 bg-hero-gradient overflow-hidden">
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url(${heroImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-4 flex items-center justify-center gap-4">
            <Badge className="bg-white/20 text-white border-white/30 text-sm px-4 py-2">
              {t.hero.badge}
            </Badge>
            <Button
              size="sm"
              variant="outline"
              className="bg-white/10 text-white border-white/30 hover:bg-white/20"
              onClick={() => setLanguage(language === 'en' ? 'no' : 'en')}
            >
              <Languages className="mr-2 h-4 w-4" />
              {language === 'en' ? 'Norsk' : 'English'}
            </Button>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            <span className="text-orange-200">global</span>Working<br/>
            <span className="text-white/90">{t.hero.title}</span>
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-4xl mx-auto">
            {t.hero.subtitle}
            <span className="block mt-2 text-lg text-white/80">
              {t.hero.features}
            </span>
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-orange-50"
              onClick={scrollToCandidates}
            >
              <UserCheck className="mr-2 h-5 w-5" />
              {t.hero.exploreCandidates}
            </Button>
            <Button 
              size="lg" 
              className="bg-warning text-warning-foreground hover:bg-warning/90"
              onClick={handleControlPanel}
            >
              📊 {t.hero.controlPanel}
            </Button>
          </div>
          <div className="text-blue-100 text-sm">
            <span className="inline-flex items-center gap-2">
              <Clock className="h-4 w-4" />
              {t.hero.response}
            </span>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              {t.stats.title}
            </h2>
            <p className="text-muted-foreground">{t.stats.subtitle}</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 text-primary rounded-lg mb-4">
                  <stat.icon className="h-6 w-6" />
                </div>
                <div className="text-3xl font-bold text-foreground mb-2">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
          <div className="mt-12 bg-warning-light rounded-lg p-6 text-center">
            <h3 className="font-bold text-warning text-lg mb-2">
              {t.stats.premiumTitle}
            </h3>
            <p className="text-warning-foreground">
              {t.stats.premiumDesc}
            </p>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              <span className="text-warning">{t.filters.title}</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              {t.filters.subtitle}
            </p>
          </div>
          
          <SearchFiltersComponent
            filters={filters}
            onFiltersChange={setFilters}
            onSearch={handleSearch}
            onReset={handleReset}
          />
        </div>
      </section>

      {/* Specialties Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              {t.specialties.title} <span className="text-warning">{t.specialties.titleHighlight}</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              {t.specialties.subtitle}
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {specialties.map((specialty) => {
              const isSelected = filters.specialty === specialty.name;
              return (
                <Card key={specialty.name} 
                      className={`card-hover cursor-pointer transition-all duration-300 hover:scale-105 ${
                        isSelected ? 'ring-2 ring-primary bg-primary/5 border-primary' : ''
                      }`} 
                      onClick={() => handleSpecialtyClick(specialty.name)}>
                  <CardHeader className="flex flex-row items-center space-y-0 pb-2">
                    <specialty.icon className={`h-8 w-8 mr-3 ${isSelected ? 'text-primary' : 'text-primary'}`} />
                    <div className="flex-1">
                      <CardTitle className={`text-lg ${isSelected ? 'text-primary' : ''}`}>
                        {specialty.name}
                      </CardTitle>
                      <div className="flex items-center justify-between mt-2">
                        <Badge variant={isSelected ? "default" : "secondary"}>
                          {specialty.count} {t.specialties.available}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-success" />
                          <span className="text-sm text-success">{t.specialties.ready}</span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-muted-foreground">
                      {isSelected ? t.specialties.selected : `${t.specialties.clickToView} ${specialty.name.toLowerCase()}`}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Staff Grid */}
      <section id="candidates-section" className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-foreground">
              {t.staff.title} ({searchResults.length})
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">{t.staff.showingResults}</span>
              {filters.specialty && (
                <Badge variant="outline">{filters.specialty}</Badge>
              )}
              {filters.availability && (
                <Badge variant="outline">{filters.availability}</Badge>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {searchResults.map((staff) => (
              <MedicalStaffCard
                key={staff.id}
                {...staff}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
          
          {searchResults.length === 0 && (
            <div className="text-center py-12">
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">
                {t.staff.noResults}
              </h3>
              <p className="text-muted-foreground mb-4">
                {t.staff.noResultsDesc}
              </p>
              <Button onClick={handleReset} variant="outline">
                {t.staff.clearFilters}
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-hero-gradient">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">
            {t.cta.title}
          </h2>
          <p className="text-xl text-white/90 mb-8">
            {t.cta.subtitle}
          </p>
          <div className="bg-white/10 rounded-lg p-6 mb-8">
            <div className="grid md:grid-cols-3 gap-4 text-white">
              <div>
                <div className="font-bold text-lg">{t.cta.explore}</div>
                <div className="text-sm text-white/80">{t.cta.exploreDesc}</div>
              </div>
              <div>
                <div className="font-bold text-lg">{t.cta.select}</div>
                <div className="text-sm text-white/80">{t.cta.selectDesc}</div>
              </div>
              <div>
                <div className="font-bold text-lg">{t.cta.contact}</div>
                <div className="text-sm text-white/80">{t.cta.contactDesc}</div>
              </div>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-primary hover:bg-orange-50">
              {t.cta.accountManager}
            </Button>
            <Button size="lg" className="bg-warning text-warning-foreground hover:bg-warning/90">
              {t.cta.reports}
            </Button>
          </div>
        </div>
      </section>

      {/* Staff Detail Modal */}
      <StaffDetailModal
        staff={selectedStaff}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onScheduleInterview={handleScheduleInterview}
        onViewContract={handleViewContract}
        onViewCosts={handleViewCosts}
      />
    </div>
  );
};

export default Index;
