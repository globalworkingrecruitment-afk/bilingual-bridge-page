export interface StaffMember {
  id: string;
  name: string;
  specialty: string;
  experience: number;
  availability: "available" | "pending" | "busy";
  rating: number;
  location: string;
  languages: string[];
  availableFrom: string;
  contractType: string;
  photo: string;
  certifications: string[];
  education: string[];
  email: string;
  phone: string;
  description: string;
  hourlyRate: number;
  monthlyRate: number;
  skills: string[];
}

export const mockStaff: StaffMember[] = [
  // Especialistas Geriátricos
  {
    id: "1",
    name: "María Elena González",
    specialty: "Especialistas Geriátricos",
    experience: 8,
    availability: "available",
    rating: 4.9,
    location: "Madrid, España",
    languages: ["Español", "Noruego", "Inglés"],
    availableFrom: "15/01/2025",
    contractType: "Flexible (3-12 meses)",
    photo: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop&crop=face",
    certifications: ["Especialista en Geriatría", "Certificación Europea EN", "Noruego B2"],
    education: ["Máster en Geriatría - Universidad Complutense", "Enfermería - Universidad de Barcelona"],
    email: "maria.gonzalez@medstaff.com",
    phone: "+34 600 123 456",
    description: "Especialista en geriatría con amplia experiencia en cuidados paliativos y demencias. Ha trabajado en centros de alta complejidad y tiene excelente adaptabilidad cultural.",
    hourlyRate: 35,
    monthlyRate: 4200,
    skills: ["Cuidados paliativos", "Demencias", "Alzheimer", "Fisioterapia geriátrica"]
  },
  {
    id: "2", 
    name: "Carlos Ruiz Mendoza",
    specialty: "Especialistas Geriátricos",
    experience: 12,
    availability: "available",
    rating: 4.8,
    location: "Valencia, España", 
    languages: ["Español", "Finlandés", "Sueco", "Inglés"],
    availableFrom: "01/02/2025",
    contractType: "Largo plazo (1-2 años)",
    photo: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop&crop=face",
    certifications: ["Especialista en Geriatría", "Finlandés C1", "Rehabilitación Cognitiva"],
    education: ["Doctorado en Geriatría - Universidad de Helsinki", "Enfermería - Universidad de Valencia"],
    email: "carlos.ruiz@medstaff.com", 
    phone: "+34 600 234 567",
    description: "Doctor especializado en geriatría con experiencia previa en hospitales finlandeses. Experto en rehabilitación cognitiva y manejo de pacientes con deterioro cognitivo leve.",
    hourlyRate: 42,
    monthlyRate: 5200,
    skills: ["Rehabilitación cognitiva", "Terapias no farmacológicas", "Evaluación geriátrica", "Cuidados intensivos geriátricos"]
  },

  // Especialistas en Urgencias
  {
    id: "3",
    name: "Ana Sofía Herrera", 
    specialty: "Especialistas en Urgencias",
    experience: 6,
    availability: "available",
    rating: 4.9,
    location: "Barcelona, España",
    languages: ["Español", "Noruego", "Inglés", "Catalán"],
    availableFrom: "10/01/2025",
    contractType: "Rotativo (6 meses)",
    photo: "https://images.unsplash.com/photo-1594824475506-b9b8a8862ea7?w=400&h=400&fit=crop&crop=face",
    certifications: ["Urgencias y Emergencias", "ACLS", "Noruego B2", "Trauma Avanzado"],
    education: ["Especialidad en Urgencias - Hospital Clínico Barcelona", "Enfermería - Universidad Pompeu Fabra"],
    email: "ana.herrera@medstaff.com",
    phone: "+34 600 345 678", 
    description: "Enfermera especialista en urgencias con amplia experiencia en servicios de emergencia de alta demanda. Certificada en soporte vital avanzado y manejo de trauma.",
    hourlyRate: 38,
    monthlyRate: 4600,
    skills: ["Soporte vital avanzado", "Manejo de trauma", "Triage", "Reanimación cardiopulmonar"]
  },
  {
    id: "4",
    name: "Diego Martín Santos",
    specialty: "Especialistas en Urgencias",
    experience: 10,
    availability: "pending",
    rating: 4.7,
    location: "Sevilla, España",
    languages: ["Español", "Finlandés", "Inglés"],
    availableFrom: "20/02/2025", 
    contractType: "Temporal (3-6 meses)",
    photo: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=400&h=400&fit=crop&crop=face",
    certifications: ["Urgencias Médicas", "Finlandés B2", "Medicina de Emergencia", "PHTLS"],
    education: ["Medicina de Urgencias - Universidad de Sevilla", "Residencia en Emergencias - Hospital Virgen del Rocío"],
    email: "diego.santos@medstaff.com",
    phone: "+34 600 456 789",
    description: "Médico especialista en urgencias con sólida formación en medicina de emergencia. Ha trabajado en unidades de cuidados intensivos y servicios de trauma.",
    hourlyRate: 45,
    monthlyRate: 5800,
    skills: ["Medicina de emergencia", "Cuidados intensivos", "Procedimientos invasivos", "Manejo de shock"]
  },

  // Especialistas en Atención Infantil
  {
    id: "5",
    name: "Laura Jiménez Vega",
    specialty: "Especialistas en Atención Infantil", 
    experience: 7,
    availability: "available",
    rating: 5.0,
    location: "Bilbao, España",
    languages: ["Español", "Noruego", "Euskera", "Inglés"],
    availableFrom: "05/01/2025",
    contractType: "Flexible (6-18 meses)",
    photo: "https://images.unsplash.com/photo-1551847364-c3de83b38b83?w=400&h=400&fit=crop&crop=face", 
    certifications: ["Pediatría Especializada", "Noruego C1", "Cuidados Intensivos Pediátricos"],
    education: ["Especialidad en Pediatría - Hospital de Cruces", "Enfermería - Universidad del País Vasco"],
    email: "laura.jimenez@medstaff.com",
    phone: "+34 600 567 890",
    description: "Enfermera pediátrica especializada con experiencia en unidades de cuidados intensivos neonatales. Excelente comunicación con familias y manejo de situaciones complejas.", 
    hourlyRate: 40,
    monthlyRate: 4800,
    skills: ["Cuidados intensivos neonatales", "Apoyo familiar", "Procedimientos pediátricos", "Desarrollo infantil"]
  },
  {
    id: "6",
    name: "Roberto Silva Campos",
    specialty: "Especialistas en Atención Infantil",
    experience: 9,
    availability: "available", 
    rating: 4.8,
    location: "Zaragoza, España",
    languages: ["Español", "Finlandés", "Inglés"],
    availableFrom: "25/01/2025",
    contractType: "Medio plazo (6-12 meses)",
    photo: "https://images.unsplash.com/photo-1637059824899-a441006a6875?w=400&h=400&fit=crop&crop=face",
    certifications: ["Pediatría Avanzada", "Finlandés B2", "Neonatología", "RCP Pediátrica"],
    education: ["Pediatría - Hospital Miguel Servet", "Medicina - Universidad de Zaragoza"], 
    email: "roberto.silva@medstaff.com",
    phone: "+34 600 678 901",
    description: "Pediatra con amplia experiencia en neonatología y cuidados críticos pediátricos. Ha participado en programas de intercambio con hospitales nórdicos.",
    hourlyRate: 43,
    monthlyRate: 5400,
    skills: ["Neonatología", "Cuidados críticos pediátricos", "Cirugía pediátrica menor", "Oncología pediátrica"]
  },

  // Enfermería General
  {
    id: "7", 
    name: "Patricia López Morales",
    specialty: "Enfermería General",
    experience: 5,
    availability: "available",
    rating: 4.6,
    location: "Granada, España", 
    languages: ["Español", "Noruego", "Inglés"],
    availableFrom: "12/01/2025",
    contractType: "Rotativo (3-9 meses)",
    photo: "https://images.unsplash.com/photo-1582750433497-86c6ad8535e1?w=400&h=400&fit=crop&crop=face",
    certifications: ["Enfermería General", "Noruego B1", "Administración de Medicamentos"],
    education: ["Enfermería - Universidad de Granada", "Máster en Cuidados Especializados"],
    email: "patricia.lopez@medstaff.com",
    phone: "+34 600 789 012",
    description: "Enfermera general con sólida formación en cuidados hospitalarios y domiciliarios. Experiencia en plantas de hospitalización y consultas ambulatorias.",
    hourlyRate: 32,
    monthlyRate: 3800,
    skills: ["Cuidados generales", "Administración de medicamentos", "Apoyo al paciente", "Registro clínico"]
  },
  {
    id: "8",
    name: "Miguel Ángel Torres",
    specialty: "Cuidados Intensivos", 
    experience: 11,
    availability: "busy",
    rating: 4.9,
    location: "Málaga, España",
    languages: ["Español", "Finlandés", "Sueco", "Inglés"],
    availableFrom: "15/03/2025",
    contractType: "Permanente",
    photo: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop&crop=face",
    certifications: ["UCI Especializada", "Finlandés C1", "Ventilación Mecánica", "ECMO"],
    education: ["Especialidad en Cuidados Intensivos - Hospital La Paz", "Enfermería - Universidad de Málaga"],
    email: "miguel.torres@medstaff.com", 
    phone: "+34 600 890 123",
    description: "Especialista en cuidados intensivos con amplia experiencia en ventilación mecánica y soporte vital avanzado. Ha trabajado en unidades de transplante.",
    hourlyRate: 48,
    monthlyRate: 6200,
    skills: ["Ventilación mecánica", "Soporte vital", "Monitorización avanzada", "ECMO"]
  }
];

export const getStaffBySpecialty = (specialty: string) => {
  return mockStaff.filter(staff => staff.specialty === specialty);
};

export const getAvailableStaff = () => {
  return mockStaff.filter(staff => staff.availability === "available");
};

export const searchStaff = (filters: any) => {
  let filteredStaff = [...mockStaff];
  
  if (filters.specialty) {
    filteredStaff = filteredStaff.filter(staff => 
      staff.specialty === filters.specialty
    );
  }
  
  if (filters.availability && filters.availability !== "all") {
    filteredStaff = filteredStaff.filter(staff => 
      staff.availability === filters.availability
    );
  }
  
  if (filters.experience) {
    const [min, max] = filters.experience.split('-').map((n: string) => parseInt(n));
    filteredStaff = filteredStaff.filter(staff => {
      if (filters.experience.includes('+')) {
        return staff.experience >= min;
      }
      return staff.experience >= min && staff.experience <= max;
    });
  }
  
  if (filters.languages && filters.languages.length > 0) {
    filteredStaff = filteredStaff.filter(staff =>
      filters.languages.some((lang: string) => staff.languages.includes(lang))
    );
  }
  
  if (filters.location) {
    filteredStaff = filteredStaff.filter(staff =>
      staff.location.toLowerCase().includes(filters.location.toLowerCase())
    );
  }
  
  return filteredStaff.slice(0, filters.quantity || filteredStaff.length);
};